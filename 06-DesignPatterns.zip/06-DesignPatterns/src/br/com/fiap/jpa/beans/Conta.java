package br.com.fiap.jpa.beans;

import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;




@Entity
@SequenceGenerator(allocationSize = 1, sequenceName = "SQ_TB_CONTA", name = "sequencia_conta")
@Table(name="TB_CONTA")
public class Conta {
	
	
	
	public Conta() {
		super();
	}

	public Conta(int num, Tipo tipo, float valor, Calendar dataAbertura) {
		super();
		this.num = num;
		this.tipo = tipo;
		this.valor = valor;
		this.dataAbertura = dataAbertura;
	}

	@Id
	@GeneratedValue(generator = "sequencia_conta", strategy = GenerationType.SEQUENCE)
	@Column(name = "cd_conta", nullable = false)
	private int conta;

	@Column(name = "nr_agencia", nullable = false)
	private int num;
	
	
	@Enumerated(EnumType.STRING)
	@Column(name = "ds_tipo", nullable = false)
	private Tipo tipo;
	
	
	@Column(name = "vl_saldo", nullable = false)
	private float valor;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "dt_abertura", nullable = false)
	private Calendar dataAbertura;

	public int getConta() {
		return conta;
	}

	public void setConta(int conta) {
		this.conta = conta;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public Tipo getTipo() {
		return tipo;
	}

	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	public Calendar getDataAbertura() {
		return dataAbertura;
	}

	public void setDataAbertura(Calendar dataAbertura) {
		this.dataAbertura = dataAbertura;
	}

	
	
}
