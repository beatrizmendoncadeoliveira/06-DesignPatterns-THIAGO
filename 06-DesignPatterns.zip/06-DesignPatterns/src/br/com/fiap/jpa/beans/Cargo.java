package br.com.fiap.jpa.beans;

public enum Cargo {
	ANALISTA, ESTAGIO
}
