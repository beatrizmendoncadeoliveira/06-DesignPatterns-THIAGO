package br.com.fiap.jpa.beans;

import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_COLABORADOR2")
@SequenceGenerator(allocationSize = 1, name = "sequencia_colaborador", sequenceName = "SQ_TB_FUNCIONARIO")
public class Colaborador {
	
	public Colaborador(String nome, Cargo cargo, Calendar dataAdmissao, float valor) {
		super();
		this.nome = nome;
		this.cargo = cargo;
		this.dataAdmissao = dataAdmissao;
		this.valor = valor;
	}


	public Colaborador() {
		super();
	}


	@Id
	@GeneratedValue(generator = "sequencia_colaborador", strategy = GenerationType.SEQUENCE)
	@Column(name = "cd_colaborador", nullable = false)
	private int cod;
	
	
	@Column(name = "nm_colaborador", nullable = false, length = 100)
	private String nome;
	
	
	@Column(name = "ds_cargo", nullable = false)
	@Enumerated(EnumType.STRING)
	private Cargo cargo;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "dt_admissao", nullable = false)
	private Calendar dataAdmissao;	
	
	
	@Column(name = "vl_salario", nullable = false)
	private float valor;


	public int getCod() {
		return cod;
	}


	public void setCod(int cod) {
		this.cod = cod;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public Cargo getCargo() {
		return cargo;
	}


	public void setCargo(Cargo cargo) {
		this.cargo = cargo;
	}


	public Calendar getDataAdmissao() {
		return dataAdmissao;
	}


	public void setDataAdmissao(Calendar dataAdmissao) {
		this.dataAdmissao = dataAdmissao;
	}


	public float getValor() {
		return valor;
	}


	public void setValor(float valor) {
		this.valor = valor;
	}


	

}
