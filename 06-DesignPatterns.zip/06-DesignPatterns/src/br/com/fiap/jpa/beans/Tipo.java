package br.com.fiap.jpa.beans;

public enum Tipo {
	CORRENTE, POUPANCA;
	

}
