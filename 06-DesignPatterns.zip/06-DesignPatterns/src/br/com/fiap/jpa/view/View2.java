package br.com.fiap.jpa.view;

import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import br.com.fiap.jpa.beans.Cargo;
import br.com.fiap.jpa.beans.Colaborador;
import br.com.fiap.jpa.dao.GenericDAO;
import br.com.fiap.jpa.dao.impl.GenericDAOImpl;
import br.com.fiap.jpa.excecao.CommitException;
import br.com.fiap.jpa.singleton.EntityManagerFactorySingleton;

public class View2 {
	
	public static void main(String[] args) {
		
		EntityManagerFactory f=EntityManagerFactorySingleton.getInstance();
		EntityManager em=f.createEntityManager();
		
		//Utilizar o dao generico sem precisar criar a classe e a interface
		//{}-->classe anonima=classe sem nome
		//instancia e implementa os metodos
		GenericDAO<Colaborador, Integer>dao=new GenericDAOImpl<Colaborador, Integer>(em) {};
		//crud bemmmmmm generico, a view 1 usamos quando queremos colocar algo especifico
		try {
			Colaborador cola=new Colaborador();
			cola.setCargo(Cargo.ANALISTA);
			cola.setDataAdmissao(Calendar.getInstance());
			cola.setNome("BIA");
			cola.setValor(12);
			dao.cadastrar(cola);
			dao.commit();
		} catch (CommitException e) {
			
		System.out.println("Erro ao cadastrar");
		}
		em.close();
		f.close();
	}

}
