package br.com.fiap.jpa.view;

import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import br.com.fiap.jpa.beans.Conta;
import br.com.fiap.jpa.beans.Tipo;
import br.com.fiap.jpa.dao.ContaDAO;
import br.com.fiap.jpa.dao.impl.ContaDAOImpl;
import br.com.fiap.jpa.singleton.EntityManagerFactorySingleton;

public class View {

	public static void main(String[] args) {
		// Obter uma instancia da Fabrica
		//como o metodo getinstance � static eu consigo acessar o metodo da classe apenas com o .
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		//Instanciar um entity
		EntityManager em=fabrica.createEntityManager();
		//Instanciar um DAO
		ContaDAO dao=new ContaDAOImpl(em);
		
		
		//Cadastrar uma conta
		Conta c= new Conta(2,Tipo.CORRENTE,100,Calendar.getInstance());
		
		try {
			dao.cadastrar(c);
			dao.commit();
			System.out.println("Conta cadastrada!");
			
		}catch (Exception e) {
			System.out.println("Erro!!!!!!!!!!!!!!!!!!!!!!!!!");
		}
		
		
		
		
		
		
		// fechar a fabrica
		fabrica.close();

	}
}
