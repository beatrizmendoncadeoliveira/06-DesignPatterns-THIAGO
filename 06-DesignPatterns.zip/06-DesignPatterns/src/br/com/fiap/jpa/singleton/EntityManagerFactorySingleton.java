package br.com.fiap.jpa.singleton;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

//Classe que gerencia a fabrica de entity manager,
//permitindo somente uma unica instancia da fabrica.

public class EntityManagerFactorySingleton {

	// atributo estatico que armazena a unica instancia
	private static EntityManagerFactory fabrica;

	//Construtor privado nao � possivel instanciar a classe, pois acessamos o metodo
	private EntityManagerFactorySingleton() {
		
	}
	
	// metodo estatico que retorna a unica instancia
	// cria uma vez e retorna sempre que for chamado
	public static EntityManagerFactory getInstance() {
		if (fabrica == null) {// so vai criar se estiver vazio, se nao estiver vazio ele retorna a fabrica ja criada				
			fabrica = Persistence.createEntityManagerFactory("oracle");
		}
		return fabrica;
	}
	

}
