package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.beans.Colaborador;

public interface ColaboradorDAO extends GenericDAO<Colaborador,Integer>{

}
