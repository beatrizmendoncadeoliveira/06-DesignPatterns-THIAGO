package br.com.fiap.jpa.dao;

import javax.persistence.EntityManager;

import br.com.fiap.jpa.beans.Colaborador;
import br.com.fiap.jpa.dao.impl.GenericDAOImpl;

public class ColaboradorDAOImpl extends GenericDAOImpl<Colaborador,Integer> implements ColaboradorDAO{

	public ColaboradorDAOImpl(EntityManager em) {
		super(em);
	}
	

}
