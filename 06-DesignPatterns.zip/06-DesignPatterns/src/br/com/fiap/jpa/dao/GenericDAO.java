package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.excecao.CommitException;
import br.com.fiap.jpa.excecao.KeyNotFoundException;

public interface GenericDAO<T,K> {
	
	//T DE TYPE=classe
	//K DE chave--qual � o tipo da chave
	void cadastrar(T entity);
	void atualizar(T entity);//recebe todos os atributos para escolhermos oq queremos q seja atualizados
	void deletar(K id)throws KeyNotFoundException;
	T pesquisar(K id)throws KeyNotFoundException;
	void commit()throws CommitException;
	
	
}
