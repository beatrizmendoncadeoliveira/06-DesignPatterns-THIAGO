package br.com.fiap.jpa.dao.impl;

import javax.persistence.EntityManager;

import br.com.fiap.jpa.beans.Conta;
import br.com.fiap.jpa.dao.ContaDAO;

public class ContaDAOImpl extends GenericDAOImpl<Conta, Integer> implements ContaDAO {

	public ContaDAOImpl(EntityManager em) {
		super(em);
		
	}

}
