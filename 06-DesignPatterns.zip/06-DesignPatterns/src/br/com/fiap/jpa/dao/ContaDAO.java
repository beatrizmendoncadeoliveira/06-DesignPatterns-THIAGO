package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.beans.Conta;

public interface ContaDAO extends GenericDAO<Conta, Integer> {

}
